/// <reference types="expo/types" />

// NOTE: This file should not be edited and should be in your git ignore